const codeInput = document.getElementById('code')
const statusEl = document.getElementById('status')
const pairBtn = document.getElementById('pair')
const refreshBtn = document.getElementById('refresh')
const forgetBtn = document.getElementById('forget')

function setStatus(text) {
  statusEl.textContent = text
}

async function sendMessage(message) {
  return await chrome.runtime.sendMessage(message)
}

async function refreshStatus() {
  const result = await sendMessage({ type: 'status' })
  if (result?.ok) {
    setStatus(result.paired ? 'Paired and ready to forward downloads.' : 'Extension is not paired yet.')
  } else {
    setStatus(`Bridge unavailable: ${result?.error || 'unknown error'}`)
  }
}

pairBtn.addEventListener('click', async () => {
  const pairingCode = String(codeInput.value || '').trim()
  if (!pairingCode) {
    setStatus('Enter the pairing code from OmniForge.')
    return
  }
  setStatus('Pairing...')
  const result = await sendMessage({ type: 'pair', pairingCode, clientName: 'Chrome/Edge' })
  if (result?.ok) {
    setStatus('Paired. Browser downloads will now forward to OmniForge.')
  } else {
    setStatus(`Pairing failed: ${result?.error || 'unknown error'}`)
  }
})

refreshBtn.addEventListener('click', () => {
  void refreshStatus()
})

forgetBtn.addEventListener('click', async () => {
  await sendMessage({ type: 'reset' })
  codeInput.value = ''
  setStatus('Pairing cleared.')
})

void refreshStatus()
