const BRIDGE_URLS = [
  'http://127.0.0.1:32157',
  'http://localhost:32157'
]

const STORAGE_KEYS = {
  token: 'omniforgeDownloadToken',
  bridgeUrl: 'omniforgeDownloadBridgeUrl'
}

async function storageGet(keys) {
  return await chrome.storage.local.get(keys)
}

async function storageSet(values) {
  await chrome.storage.local.set(values)
}

async function storageRemove(keys) {
  await chrome.storage.local.remove(keys)
}

async function getState() {
  const data = await storageGet([STORAGE_KEYS.token, STORAGE_KEYS.bridgeUrl])
  return {
    token: data[STORAGE_KEYS.token] || '',
    bridgeUrl: data[STORAGE_KEYS.bridgeUrl] || BRIDGE_URLS[0]
  }
}

async function postJson(path, body, withAuth = true) {
  const { token, bridgeUrl } = await getState()
  const url = `${bridgeUrl}${path}`
  const headers = { 'Content-Type': 'application/json' }
  if (withAuth && token) {
    headers.Authorization = `Bearer ${token}`
  }
  const res = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body)
  })
  return await res.json()
}

async function getJson(path, withAuth = true) {
  const { token, bridgeUrl } = await getState()
  const url = `${bridgeUrl}${path}`
  const headers = {}
  if (withAuth && token) {
    headers.Authorization = `Bearer ${token}`
  }
  const res = await fetch(url, { headers })
  return await res.json()
}

function normalizeDownload(item) {
  const url = item.finalUrl || item.url
  if (!url) return null

  const filename = item.filename || item.suggestedFilename || ''
  return {
    url,
    filename,
    referrer: item.referrer || '',
    source: 'browser-extension',
    tabUrl: item.tabUrl || '',
    mimeType: item.mime || '',
    extensionId: item.byExtensionId || '',
    userAgent: navigator.userAgent,
    headers: {}
  }
}

async function forwardDownload(item) {
  const state = await getState()
  if (!state.token) return

  const payload = normalizeDownload(item)
  if (!payload) return

  try {
    await chrome.downloads.cancel(item.id)
  } catch {
    // Best effort. Some downloads may already be past the cancel window.
  }

  const result = await postJson('/downloads', payload)
  if (!result.ok && result.error) {
    console.warn('OmniForge download bridge rejected request:', result.error)
  }
}

chrome.downloads.onCreated.addListener((item) => {
  void forwardDownload(item)
})

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message !== 'object') return false

  if (message.type === 'pair') {
    void (async () => {
      const code = String(message.pairingCode || '').trim()
      const clientName = String(message.clientName || 'browser-extension')
      const result = await postJson('/pair', { pairingCode: code, clientName }, false)
      if (result.ok && result.token) {
        await storageSet({
          [STORAGE_KEYS.token]: result.token,
          [STORAGE_KEYS.bridgeUrl]: result.bridgeUrl || BRIDGE_URLS[0]
        })
      }
      sendResponse(result)
    })()
    return true
  }

  if (message.type === 'status') {
    void (async () => {
      try {
        const result = await getJson('/health', false)
        const state = await getState()
        sendResponse({ ok: true, bridge: result, paired: Boolean(state.token) })
      } catch (err) {
        const state = await getState()
        sendResponse({ ok: false, error: String(err), paired: Boolean(state.token) })
      }
    })()
    return true
  }

  if (message.type === 'reset') {
    void (async () => {
      await storageRemove([STORAGE_KEYS.token])
      sendResponse({ ok: true })
    })()
    return true
  }

  if (message.type === 'download-now') {
    void (async () => {
      const result = await postJson('/downloads', message.request || {})
      sendResponse(result)
    })()
    return true
  }

  return false
})
